#include <mrsh/builtin.h>
#include <stdlib.h>
#include "builtin.h"

int builtin_colon(struct mrsh_state *state, int argc, char *argv[]) {
	return 0; // This builtin does not do anything
}
