#!/bin/sh

# This is a comment

echo a  b 	 c
echo d # e f
echo 'a	b  c'
echo "a	b  c"

echo a"*"b'c"'
echo "a\"b\\" "'hey'" '"hey"' '#' \''a'
