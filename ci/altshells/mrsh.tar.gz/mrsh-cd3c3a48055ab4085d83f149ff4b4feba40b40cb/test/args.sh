func() (
	getopts "abcd" opt
)

func
func -a
func -ab
func -abc
