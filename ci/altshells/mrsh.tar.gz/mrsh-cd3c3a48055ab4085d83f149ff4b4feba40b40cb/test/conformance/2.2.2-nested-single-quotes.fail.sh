# 2.2.2 Single quotes
# Single quotes cannot contain single quotes
printf '%s\n' '''
