printf '%s\n' "cmd: `echo "`"
